#ifndef LEITURA_H
#define LEITURA_H
#include <vector>
#include <string>
#include "FiguraGeometrica.h"

class Leitura
{
    public:
        Leitura();
        std::vector<FiguraGeometrica *> parse(std::string filename);

        int getDx();
        int getDy();
        int getDz();

    protected:
        int dx,dy,dz;
        float r,g,b,a;
};

#endif // LEITURA_H