#include <math.h>
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>
#include "Sculptor.h"
#include "Leitura.h"

using namespace std;
int main(){

    Sculptor *saturno;
    Sculptor *teste;
    Leitura ler, ler2;

    vector<FiguraGeometrica*> figuras;
    vector<FiguraGeometrica*> figuras2;

    figuras = ler.parse("saturn.txt");
    saturno = new Sculptor(ler.getDx(), ler.getDy(), ler.getDz());

    figuras2 = ler2.parse("teste.txt");
    teste = new Sculptor(ler2.getDx(), ler2.getDy(), ler2.getDz());

    for(size_t i = 0; i < figuras.size(); i++){
        figuras[i] -> draw(*saturno);
    }

    for(size_t i = 0; i < figuras2.size(); i++){
        figuras2[i] -> draw(*teste);
    }

    saturno -> writeOFF("saturno.off");
    teste -> writeOFF("teste.off");

}