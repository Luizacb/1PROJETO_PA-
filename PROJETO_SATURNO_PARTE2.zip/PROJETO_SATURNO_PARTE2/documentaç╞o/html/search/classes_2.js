var searchData=
[
  ['leitura_0',['Leitura',['../class_leitura.html',1,'']]]
];
