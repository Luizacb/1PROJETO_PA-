var searchData=
[
  ['y_0',['y',['../class_cut_voxel.html#ae62d619cb2e91cddc1cd73053b1afc89',1,'CutVoxel::y'],['../class_put_voxel.html#a570160947f9ef0a8f541e9cabb96d5f7',1,'PutVoxel::y']]],
  ['y0_1',['y0',['../class_cut_box.html#ab8bd7a8a94c1336daad8d808f5d62f68',1,'CutBox::y0'],['../class_put_box.html#acc1b4deb4f10ebe0417e2da420e0d3d1',1,'PutBox::y0']]],
  ['y1_2',['y1',['../class_cut_box.html#acefed2c5a0564ea68946266f60018176',1,'CutBox::y1'],['../class_put_box.html#a7153a65fd7cc6a387a09dbcaf1b2176c',1,'PutBox::y1']]],
  ['ycenter_3',['ycenter',['../class_cut_ellipsoid.html#aedef6b2ff0039d457490f216db6363e2',1,'CutEllipsoid::ycenter'],['../class_cut_sphere.html#adf21bbf750b8e318db9a02786881542e',1,'CutSphere::ycenter'],['../class_put_ellipsoid.html#a3020ba6a4020b25173756101b33e07ac',1,'PutEllipsoid::ycenter'],['../class_put_sphere.html#a2273d70cbc731c9521d6212248f8e807',1,'PutSphere::ycenter']]]
];
