var searchData=
[
  ['a_0',['a',['../class_figura_geometrica.html#ae7c8a027fcec3c357265b90458a4d165',1,'FiguraGeometrica::a'],['../class_leitura.html#a26d441578a4d2871c24cadd1760e92c1',1,'Leitura::a'],['../struct_voxel.html#a3ce2579eb0a9f09a07112ce7498a638e',1,'Voxel::a']]]
];
