var searchData=
[
  ['sculptor_0',['Sculptor',['../class_sculptor.html#a014e3ef5517bf0e9d9e14486b6ac6433',1,'Sculptor']]],
  ['setcolor_1',['setColor',['../class_sculptor.html#a4351c930a07887e96d4fdbf251a7867e',1,'Sculptor']]]
];
