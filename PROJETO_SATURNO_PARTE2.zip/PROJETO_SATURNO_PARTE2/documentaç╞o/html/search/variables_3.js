var searchData=
[
  ['g_0',['g',['../class_figura_geometrica.html#a51930549bcb90d016b824f10f95df355',1,'FiguraGeometrica::g'],['../class_leitura.html#a3fecfee4d73022798dfd189d4e279ea3',1,'Leitura::g'],['../struct_voxel.html#a27c0da1ed2ff430401d23ff171612a73',1,'Voxel::g']]]
];
