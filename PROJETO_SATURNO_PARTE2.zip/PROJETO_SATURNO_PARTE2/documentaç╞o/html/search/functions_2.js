var searchData=
[
  ['getdx_0',['getDx',['../class_leitura.html#a3e9b1dada9159a90be3ebef94ca64fb1',1,'Leitura']]],
  ['getdy_1',['getDy',['../class_leitura.html#a6778bea12deb8b9313d1946ecb8dd820',1,'Leitura']]],
  ['getdz_2',['getDz',['../class_leitura.html#abb4380424dfbb78903515dd8e9221e82',1,'Leitura']]]
];
