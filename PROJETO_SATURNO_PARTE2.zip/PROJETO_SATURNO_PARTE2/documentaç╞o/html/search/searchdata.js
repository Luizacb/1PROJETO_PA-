var indexSectionsWithContent =
{
  0: "abcdfglmprsvwxyz~",
  1: "cflpsv",
  2: "cflmps",
  3: "cdglmpsw~",
  4: "abdgrsxyz"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Arquivos",
  3: "Funções",
  4: "Variáveis"
};

