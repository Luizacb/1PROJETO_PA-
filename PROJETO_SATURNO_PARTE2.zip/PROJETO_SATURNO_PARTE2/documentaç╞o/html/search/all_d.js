var searchData=
[
  ['x_0',['x',['../class_cut_voxel.html#ae7338462b96d9f85b844d4c927765213',1,'CutVoxel::x'],['../class_put_voxel.html#acc09df6a9ef63de8e380c8ba05dc7053',1,'PutVoxel::x']]],
  ['x0_1',['x0',['../class_cut_box.html#a9b3c2e2f41f7f73f324c59d11fc73e9b',1,'CutBox::x0'],['../class_put_box.html#a61d3aac24126b01a16f9748d24642ae2',1,'PutBox::x0']]],
  ['x1_2',['x1',['../class_cut_box.html#ad1f788477c892d4e1362c144be70e547',1,'CutBox::x1'],['../class_put_box.html#add706addc4c81d0b25219c13fa8fc75d',1,'PutBox::x1']]],
  ['xcenter_3',['xcenter',['../class_cut_ellipsoid.html#a370c6da160f24d68270f8964e4579750',1,'CutEllipsoid::xcenter'],['../class_cut_sphere.html#a9b02dc65220b2e2eb2d97c0ec282375a',1,'CutSphere::xcenter'],['../class_put_ellipsoid.html#ab0bbb7252f3e0dc9d7cdd8e01df14935',1,'PutEllipsoid::xcenter'],['../class_put_sphere.html#ab6b78fcab3261c56d7ad2368afdc9cc4',1,'PutSphere::xcenter']]]
];
