var searchData=
[
  ['r_0',['r',['../struct_voxel.html#a06872ec79b836120b551a848968c0f1b',1,'Voxel']]]
];
