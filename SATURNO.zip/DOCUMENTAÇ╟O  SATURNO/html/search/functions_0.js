var searchData=
[
  ['addstars_0',['addStars',['../main_8cpp.html#a14f7907297f65f850d6f945946418695',1,'main.cpp']]]
];
